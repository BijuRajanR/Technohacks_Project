import tkinter as tk
from tkinter import messagebox
import time

class CountdownTimer:
    def __init__(self, root):
        self.root = root
        self.root.title("Countdown Timer")

        self.seconds_left = 0
        self.running = False

        self.label = tk.Label(root, text="")
        self.label.pack(pady=20)

        self.start_button = tk.Button(root, text="Start", command=self.start_timer)
        self.start_button.pack()
        
        self.stop_button = tk.Button(root, text="Stop", command=self.stop_timer, state=tk.DISABLED)
        self.stop_button.pack()

        self.reset_button = tk.Button(root, text="Reset", command=self.reset_timer, state=tk.DISABLED)
        self.reset_button.pack()

        self.update_display()

    def start_timer(self):
        if not self.running:
            self.running = True
            self.seconds_left = 30  # Set your desired countdown time in seconds
            self.update_timer()

            self.start_button.config(state=tk.DISABLED)
            self.stop_button.config(state=tk.NORMAL)
            self.reset_button.config(state=tk.NORMAL)

    def stop_timer(self):
        self.running = False
        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)

    def reset_timer(self):
        self.running = False
        self.seconds_left = 0
        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.reset_button.config(state=tk.DISABLED)
        self.update_display()

    def update_timer(self):
        if self.running and self.seconds_left > 0:
            self.seconds_left -= 1
            self.update_display()
            self.root.after(1000, self.update_timer)  # Update every 1000ms (1 second)
        elif self.seconds_left == 0:
            self.running = False
            messagebox.showinfo("Timer Finished", "The countdown timer has reached zero.")
            self.reset_timer()

    def update_display(self):
        minutes, seconds = divmod(self.seconds_left, 60)
        self.label.config(text=f"{minutes:02d}:{seconds:02d}")

if __name__ == "__main__":
    root = tk.Tk()
    timer = CountdownTimer(root)
    root.mainloop()
